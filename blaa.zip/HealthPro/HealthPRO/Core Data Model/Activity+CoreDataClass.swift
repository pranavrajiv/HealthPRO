//
//  Activity+CoreDataClass.swift
//  HealthPRO
//
//  Created by Pranav Rajiv on 4/30/22.
//
//

import Foundation
import CoreData

@objc(Activity)
public class Activity: NSManagedObject {

}
