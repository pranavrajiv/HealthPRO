//
//  User+CoreDataClass.swift
//  HealthPRO
//
//  Created by Pranav Rajiv on 4/30/22.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
